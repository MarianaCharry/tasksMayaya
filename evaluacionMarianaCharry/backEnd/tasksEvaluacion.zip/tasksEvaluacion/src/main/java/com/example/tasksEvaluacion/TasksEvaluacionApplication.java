package com.example.tasksEvaluacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TasksEvaluacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(TasksEvaluacionApplication.class, args);
	}

}
