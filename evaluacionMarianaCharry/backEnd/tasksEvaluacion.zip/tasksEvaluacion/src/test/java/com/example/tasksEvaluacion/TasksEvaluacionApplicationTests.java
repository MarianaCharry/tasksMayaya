package com.example.tasksEvaluacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasksEvaluacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
